class UnicodeJapan {
    public static void main(String[] args) {
        char ch1 = 0x3041;
        char ch2 = 0x3051;
        char ch3 = 0x3061;
        char ch4 = 0x3071;

        System.out.println(ch1 + " " + ch2 + " " + ch3 + " " + ch4);

        ch1 = 0x3043;
        ch2 = 0x3053;
        ch3 = 0x3063;
        ch4 = 0x3073;
        System.out.println(ch1 + " " + ch2 + " " + ch3 + " " + ch4);
    }
}
