class RelationalOp {
    public static void main(String[] args) {
        System.out.println("3 >= 2 : " + (3 >= 2));
        System.out.println("3 <= 2 : " + (3 <= 2));

        System.out.println("7.0 == 7 : " + (7.0 == 7));
        System.out.println("7.0 != 7 : " + (7.0 != 7));
    }
}