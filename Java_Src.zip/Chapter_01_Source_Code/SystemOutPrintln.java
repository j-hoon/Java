class SystemOutPrintln
{
    public static void main(String[] args)
    {
        System.out.println(7);
        System.out.println(3.15);
        System.out.println("3 + 5 = " + 8);
        System.out.println(3.15 + "는 실수입니다.");	
        System.out.println("3 + 5" + " 의 연산 결과는 8 입니다.");
        System.out.println(3 + 5);
    }
}
