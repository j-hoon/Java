class UnicodeEscapes {
    public static void main(String[] args) {
        System.out.println("오늘의 환율은 1$에 0.88" + '\u20AC' + "입니다.");
    }
}