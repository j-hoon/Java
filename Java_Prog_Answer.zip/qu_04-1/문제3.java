class SimpleOpSte {
    public static void main(String[] args) {
        int result = ((25 * 5) + (36 - 4) - 72) / 5;
        System.out.println(result);
    }
}

/*
   자바의 연산자에는 수학에서 의미하는 중괄호가 존재하지 않는다. 
   중괄호가 있긴 하지만 다른 의미로 사용이 된다. 
   대신 중괄호도 그냥 소괄호로 처리하면 된다.
*/
